package com.example.emicalculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HomeScreen extends AppCompatActivity {

    // Variables for user input fields
    private EditText principalAmountEditText, interestRateEditText, amortizationPeriodEditText, paymentFrequencyEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home_screen);

        // Handling system bars insets for proper layout
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Find the input fields
        principalAmountEditText = findViewById(R.id.principalAmount);
        interestRateEditText = findViewById(R.id.interestRate);
        amortizationPeriodEditText = findViewById(R.id.amortizationPeriod);
        paymentFrequencyEditText = findViewById(R.id.paymentFrequency);

        // Find the Calculate button by its ID
        Button calculateButton = findViewById(R.id.Calculate);

        // Set an OnClickListener to the button
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the input values
                String principalStr = principalAmountEditText.getText().toString();
                String interestStr = interestRateEditText.getText().toString();
                String amortizationStr = amortizationPeriodEditText.getText().toString();
                String frequencyStr = paymentFrequencyEditText.getText().toString();

                if (!principalStr.isEmpty() && !interestStr.isEmpty() && !amortizationStr.isEmpty() && !frequencyStr.isEmpty()) {
                    // Convert the input values to numbers
                    double principal = Double.parseDouble(principalStr);
                    double annualInterestRate = Double.parseDouble(interestStr);
                    int amortizationPeriod = Integer.parseInt(amortizationStr); // in years
                    int paymentFrequency = Integer.parseInt(frequencyStr); // for simplicity: 12 for monthly, 26 for bi-weekly, etc.

                    // Perform the mortgage calculation
                    double monthlyPayment = calculateMortgage(principal, annualInterestRate, amortizationPeriod, paymentFrequency);

                    // Pass the result to the Results screen
                    Intent intent = new Intent(HomeScreen.this, Results.class);
                    intent.putExtra("mortgagePayment", monthlyPayment);
                    startActivity(intent); // Start the new activity
                } else {
                    // Show a Toast if inputs are missing
                    Toast.makeText(HomeScreen.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to calculate the mortgage monthly payment
    private double calculateMortgage(double principal, double annualInterestRate, int amortizationPeriod, int paymentFrequency) {
        // Convert annual interest rate to monthly interest rate
        double monthlyInterestRate = (annualInterestRate / 100) / paymentFrequency;
        int totalPayments = amortizationPeriod * paymentFrequency; // Total number of payments

        // Formula for calculating mortgage payment
        return (principal * monthlyInterestRate) / (1 - Math.pow(1 + monthlyInterestRate, -totalPayments));
    }
}

