package com.example.emicalculator;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Results extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        // Get the result from the intent
        double mortgagePayment = getIntent().getDoubleExtra("mortgagePayment", 0);

        // Find the TextView and display the result
        TextView resultTextView = findViewById(R.id.resultTextView);
        resultTextView.setText(String.format("Your Monthly Payment: $%.2f", mortgagePayment));
    }
}
